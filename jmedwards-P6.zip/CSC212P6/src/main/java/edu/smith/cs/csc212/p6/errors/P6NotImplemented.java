package edu.smith.cs.csc212.p6.errors;

/**
 * I've defined this class for all starter code methods you need to implement.
 * @author jfoley
 */
@SuppressWarnings("serial")
public class P6NotImplemented extends RuntimeException {
	public P6NotImplemented() {
		super("P6NotImplemented");
	}
}
