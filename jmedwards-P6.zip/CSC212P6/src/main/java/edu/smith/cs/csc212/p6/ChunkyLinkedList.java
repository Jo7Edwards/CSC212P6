package edu.smith.cs.csc212.p6;

import edu.smith.cs.csc212.p6.errors.BadIndexError;
import edu.smith.cs.csc212.p6.errors.EmptyListError;
import edu.smith.cs.csc212.p6.errors.P6NotImplemented;

/**
 * This is a data structure that has an array inside each node of a Linked List.
 * Therefore, we only make new nodes when they are full. Some remove operations
 * may be easier if you allow "chunks" to be partially filled.
 * 
 * @author jfoley
 * @param <T> - the type of item stored in the list.
 */
public class ChunkyLinkedList<T> implements P6List<T> {
	private int chunkSize;
	private SinglyLinkedList<FixedSizeList<T>> chunks;

	public ChunkyLinkedList(int chunkSize) {
		this.chunkSize = chunkSize;
		chunks = new SinglyLinkedList<>();
		chunks.addBack(new FixedSizeList<>(chunkSize));
	}

	@Override
	public T removeFront() {
		if (this.isEmpty() == true) {
			throw new EmptyListError();
		}
		T removed = this.getIndex(0);
		
		chunks.getFront().removeFront();
		
		return removed;
		
	}

	@Override
	public T removeBack() {
		if (this.isEmpty() == true) {
			throw new EmptyListError();
		}
		T removed = this.getBack();
		
		chunks.getBack().removeBack();
		
		return removed;
	}
	
	/*
	 * created helper method .getChunk just for this! 
	 * find the chunk that this index is in, then delete that specific thing
	 */
	@Override
	public T removeIndex(int index) {
		if (this.isEmpty() == true) {
			throw new EmptyListError();
		}
		T removed = this.getIndex(index);
		
		FixedSizeList<T> returnChunk = this.getChunk(index);
		
		returnChunk.removeIndex(index);
		
		return removed;
	}

	@Override
	public void addFront(T item) {
		//T front = this.getFront();
		//int start = 0;
		int at = 0;
		int chunkFill = 0;
		//get the fill amount of the first chunk
		for (FixedSizeList<T> chunk : this.chunks) {
			chunkFill = chunk.size();
			break;
		}
		for (FixedSizeList<T> chunk : this.chunks) {
			//We know the first thing will be in the first chunk
			if (at == 0) {
				//if the chunk won't be over filled by adding one
				if (chunkFill +1 <= this.chunkSize) {
					chunk.addFront(item);
					break;
				} else { //if that chunk would be over filled
					//then put the item in a new chunk and add that chunk to the front
					FixedSizeList<T> newList = new FixedSizeList<T>(this.chunkSize);
					newList.addFront(item);
					chunks.addFront(newList);
					break;
				}
				
			}
		at++; //unnecessary?
		}
		
	}

	@Override
	public void addBack(T item) {
		int at = 0;
		int at2 = 0;
		int chunkFill = 0;
		/*
		 * We have a size(), but that's how many items in all the chunks, not the
		 * number of chunks. This loop counts the number of chunks, which we utilize
		 * in the second loop.
		 */
		for (FixedSizeList<T> chunk : this.chunks) {
			chunkFill = chunk.size();
			//last = chunk;
			at2++;
		}
		for (FixedSizeList<T> chunk : this.chunks) {
			at++; 
			//If we're on the last chunk
			if (at == at2) { 
				//If we're not over filling the chunk, then we can add
				if (chunkFill +1 <= this.chunkSize) {
					chunk.addBack(item);
				} else { //if that chunk would be over filled
					FixedSizeList<T> newList = new FixedSizeList<T>(this.chunkSize);
					newList.addBack(item);
					chunks.addBack(newList);
				}
			}
			
		}
	}

	@Override
	public void addIndex(T item, int index) {
		FixedSizeList<T> returnChunk = this.getChunk(index);
		int chunkFill = returnChunk.size();
		
		for (FixedSizeList<T> chunk : this.chunks) {
			 
			/*
			 * If the chunk is not filled, meaning that getChunk() ID'd it as being on the end
			 * and outside of any indexing and thus returned an empty chunk. 
			 */
			if (chunkFill == 0) {
				returnChunk.addBack(item);
				chunks.addBack(returnChunk);
			}
			//If we're on the correct chunk
			if (chunk == returnChunk) { 
				//If we're not over filling the chunk, then we can add
				if (chunkFill +1 <= this.chunkSize) {
					chunk.addIndex(item,  index);
				} else { //if that chunk would be over filled
					FixedSizeList<T> newList = new FixedSizeList<T>(this.chunkSize);
					newList.addBack(item);
					chunks.addIndex(newList, index);
				}
			}
			
		}
		
	}
	
	@Override
	public T getFront() {
		return this.chunks.getFront().getFront();
	}

	@Override
	public T getBack() {
		return this.chunks.getBack().getBack();
	}
	
	/*
	 * Helper method, returns the chunk that the index is in
	 * IF INDEX IS APPENDING to the end of a list, i.e. index == list.size(), then this
	 * will return an empty fixedSizeList chunk for the purpose of that being added on
	 */
	public FixedSizeList<T> getChunk(int index) {
		if (this.isEmpty()) {
			throw new EmptyListError();
		}
		int start = 0;
		FixedSizeList<T> returnChunk = new FixedSizeList<T>(this.chunkSize);
		for (FixedSizeList<T> chunk : this.chunks) {
			// calculate bounds of this chunk.
			int end = start + chunk.size();
			
			// Check whether the index should be in this chunk:
			if (start <= index && index < end) {
				return chunk;
			} else if (index == this.size()) {
				return returnChunk;
			}
		}
		
		throw new BadIndexError();
	}

	@Override
	public T getIndex(int index) {
		if (this.isEmpty()) {
			throw new EmptyListError();
		}
		int start = 0;
		for (FixedSizeList<T> chunk : this.chunks) {
			// calculate bounds of this chunk.
			int end = start + chunk.size();
			
			// Check whether the index should be in this chunk:
			if (start <= index && index < end) {
				return chunk.getIndex(index - start);
			}
			
			// update bounds of next chunk.
			start = end;
		}
		throw new BadIndexError();
	}
	
	//How many individual things in all the chunks
	@Override
	public int size() {
		int total = 0;
		for (FixedSizeList<T> chunk : this.chunks) {
			total += chunk.size();
		}
		return total;
	}

	@Override
	public boolean isEmpty() {
		return this.chunks.isEmpty();
	}
}
